-- queries.sql

-- SELECT queries
SELECT * FROM users;
SELECT * FROM products;
SELECT * FROM orders;

-- INSERT queries
INSERT INTO users (username, email) VALUES ('JohnDoe', 'john@example.com');
INSERT INTO products (product_name, price) VALUES ('Product A', 50.00);
INSERT INTO orders (user_id, product_id, quantity, order_date) VALUES (1, 1, 2, '2023-12-06');

-- UPDATE queries
UPDATE users SET email = 'john.doe@example.com' WHERE user_id = 1;
UPDATE products SET price = 55.00 WHERE product_id = 1;
UPDATE orders SET quantity = 3 WHERE order_id = 1;

-- DELETE queries
DELETE FROM users WHERE user_id = 1;
DELETE FROM products WHERE product_id = 1;
DELETE FROM orders WHERE order_id = 1;
