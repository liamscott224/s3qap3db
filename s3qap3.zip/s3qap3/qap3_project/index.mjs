import express from 'express';
const app = express();
import productsRoute from './routes/products.mjs';
import usersRoute from './routes/users.mjs';
import ordersRoute from './routes/orders.mjs';

app.use('/products', productsRoute);
app.use('/users', usersRoute);
app.use('/orders', ordersRoute);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
