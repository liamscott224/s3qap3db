// productsDAL.js

const pool = require('./db'); // Assuming you have a db connection pool

const getAllProducts = async () => {
    try {
        const result = await pool.query('SELECT * FROM products');
        return result.rows;
    } catch (error) {
        throw new Error(`Error while fetching products: ${error.message}`);
    }
};

const addProduct = async (productName, price) => {
    try {
        const result = await pool.query('INSERT INTO products (product_name, price) VALUES ($1, $2) RETURNING *', [productName, price]);
        return result.rows[0];
    } catch (error) {
        throw new Error(`Error while adding product: ${error.message}`);
    }
};

// Implement similar functions for updating and deleting products

module.exports = {
    getAllProducts,
    addProduct
    // Add other functions here
};
